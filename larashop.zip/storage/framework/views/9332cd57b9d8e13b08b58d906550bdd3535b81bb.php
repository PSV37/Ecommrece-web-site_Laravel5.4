<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
<script >
$(document).ready(function(){
	//get cat id
	<?php $__currentLoopData = App\Cat::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    $('#cat<?php echo e($catList->id); ?>').on('click',function(){
    	var cat_id = $('#cat<?php echo e($catList->id); ?>').val();
    	//alert(cat_id);
    	$.ajax({
    		type :'GET',
    		dataType : 'html',
    		url : "<?php echo e(url('ProductDisplay')); ?>",
    		data : {'cat_id':cat_id},

    		success:function(response){
             // console.log(response);
             $('#productsData').html(response);
    		}
    	})
    })

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
})	

</script>