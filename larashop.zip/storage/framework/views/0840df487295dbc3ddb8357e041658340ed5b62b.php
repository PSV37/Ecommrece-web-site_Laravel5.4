<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
  <h3>dashboad</h3>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>