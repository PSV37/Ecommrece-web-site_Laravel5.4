<?php $__env->startSection('content'); ?>
<?php echo $__env->make('front.productJs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="greyBg">
    <div class="container">
		<div class="wrapper">
			<div class="row">
				<div class="col-sm-12">
				<div class="breadcrumbs">
			        <ul>
			          <li><a href="#">Home</a></li>
			          <li><span class="dot">/</span> 
                     <?php if(count($data)=='0'): ?>
			          <b style="color: blue"><?php echo e($catuserby); ?></b>
			          <?php else: ?>
			          <a href="<?php echo e(url('products')); ?>/<?php echo e($catuserby); ?>"><?php echo e($catuserby); ?></a>
			          <?php endif; ?>
			           </li>
			        </ul>
                </div>
                </div>
		    </div>
		    <h1 class="text-center"><?php echo e($catuserby); ?></h1>
		    <?php if(count($data)=='0'): ?>

		    <?php else: ?>
		    <div class="row">
		    		<div class="col-xs-6 col-sm-3">
				    	<div class="nice-select">
							<span class="current">Shop Categories</span>
							<ul class="list">
								<?php $__currentLoopData = App\Cat::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							    <li class="option" value="<?php echo e($catName->id); ?>" id="cat<?php echo e($catName->id); ?>"><?php echo e($catName->cat_name); ?></li>
							   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
				    </div>
				    <div class="col-xs-6 col-sm-3">
						<select id="selectbox2">
						    <option value="">Price</option>
						    <option value="aye">Aye</option>
						    <option value="eh">Eh</option>
						    <option value="ooh">Ooh</option>
						    <option value="whoop">Whoop</option>
						</select>
				    </div>

				<div class="col-sm-6 hidden-xs">
					<div class="row">

						<div class="col-sm-4 pull-right">
							<select id="selectbox3">
							    <option value="">Sort By</option>
							    <option value="aye">Category</option>
							    <option value="eh">Products</option>
							</select>
						</div>
						<div class="styleNm">16 style(s)</div>
					</div>

				</div>
		    </div>
		    <?php endif; ?>
	    	<div class="row top25">
		      <?php if(count($data)=='0'): ?>
	            <div class="col-md-12 col-sm-offset-3" >
	       	      <h2>No Product Found Under <b style="color: red"><?php echo e($catuserby); ?></b> Category</h2>
	            </div>
		      <?php else: ?>
		      <div id="productsData">
                 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="col-xs-6 col-sm-4">
	    	         <div class="itemBox">
	    				<div class="prod">
	    					<img src="<?php echo e(url('productimages')); ?>/<?php echo e($p->pro_img); ?>" alt=""  height="270px"/>
	    				</div>
	    				<label><?php echo e($p->pro_name); ?></label>
	    				<span class="hidden-xs">Code: <?php echo e($p->pro_code); ?></span>
                <br>
              <span class="hidden-xs"><?php echo e($p->pro_info); ?></span>
	    				<div class="addcart">
	    					<div class="price">Rs <?php echo e($p->pro_price); ?></div>
	    					<div class="cartIco hidden-xs"><a href="/"><img src="<?php echo e(asset('img/cart.png')); ?>"/> </a></div>
	    				</div>
	    			</div>
	    		</div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <?php endif; ?>
	    		<?php /*<div class="col-xs-6 col-sm-4">
	    			<div class="itemBox">
	    				<div class="prod"><img src="{{Config::get('app.url')}}/theme/images/2.jpg" alt="" /></div>
	    				<label>ADD GOLD</label>
	    				<span class="hidden-xs">Does stress keep you up at night?</span>
	    				<div class="addcart">
	    					<div class="price">Rs 900.00</div>
	    					<div class="cartIco hidden-xs"><a href="/"></a></div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-xs-6 col-sm-4">
	    			<div class="itemBox">
	    				<div class="prod"><img src="{{Config::get('app.url')}}/theme/images/3.jpg" alt="" /></div>
	    				<label>ADD GROWTH</label>
	    				<span class="hidden-xs">Worried about your kid’s overall well-being? </span>
	    				<div class="addcart">
	    					<div class="price">Rs 900.00</div>
	    					<div class="cartIco hidden-xs"><a href="/"></a></div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-xs-6 col-sm-4">
	    			<div class="itemBox">
	    				<div class="prod"><img src="{{Config::get('app.url')}}/theme/images/4.jpg" alt="" /></div>
	    				<label>ADD IMMUNE</label>
	    				<span class="hidden-xs">Want to increase your immunity and keep your...</span>
	    				<div class="addcart">
	    					<div class="price">Rs 900.00</div>
	    					<div class="cartIco hidden-xs"><a href="/"></a></div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-xs-6 col-sm-4">
	    			<div class="itemBox">
	    				<div class="prod"><img src="{{Config::get('app.url')}}/theme/images/5.jpg" alt="" /></div>
	    				<label>ADD JOY</label>
	    				<span class="hidden-xs">Are you suffering from insomnia or anxiety?</span>
	    				<div class="addcart">
	    					<div class="price">Rs 900.00</div>
	    					<div class="cartIco hidden-xs"><a href="/"></a></div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-xs-6 col-sm-4">
	    			<div class="itemBox">
	    				<div class="prod"><img src="{{Config::get('app.url')}}/theme/images/6.jpg" alt="" /></div>
	    				<label>ADD HB (FOR FEMALE)</label>
	    				<span class="hidden-xs">Is your hemoglobin level is lower than normal?</span>
	    				<div class="addcart">
	    					<div class="price">Rs 900.00</div>
	    					<div class="cartIco hidden-xs"><a href="/"></a></div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-xs-6 col-sm-4">
	    			<div class="itemBox">
	    				<div class="prod"><img src="{{Config::get('app.url')}}/theme/images/1.jpg" alt="" /></div>
	    				<label>Add Energy</label>
	    				<span class="hidden-xs">Worried about your low immunity level?</span>
	    				<div class="addcart">
	    					<div class="price">Rs 900.00</div>
	    					<div class="cartIco hidden-xs"><a href="/"></a></div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-xs-6 col-sm-4">
	    			<div class="itemBox">
	    				<div class="prod"><img src="{{Config::get('app.url')}}/theme/images/2.jpg" alt="" /></div>
	    				<label>ADD GOLD</label>
	    				<span class="hidden-xs">Does stress keep you up at night?</span>
	    				<div class="addcart">
	    					<div class="price">Rs 900.00</div>
	    					<div class="cartIco hidden-xs"><a href="/"></a></div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-xs-6 col-sm-4">
	    			<div class="itemBox">
	    				<div class="prod"><img src="{{Config::get('app.url')}}/theme/images/3.jpg" alt="" /></div>
	    				<label>ADD GROWTH</label>
	    				<span class="hidden-xs">Worried about your kid’s overall well-being? </span>
	    				<div class="addcart">
	    					<div class="price">Rs 900.00</div>
	    					<div class="cartIco hidden-xs"><a href="/"></a></div>
	    				</div>
	    			</div>
	    		</div> */?>
	    	</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>