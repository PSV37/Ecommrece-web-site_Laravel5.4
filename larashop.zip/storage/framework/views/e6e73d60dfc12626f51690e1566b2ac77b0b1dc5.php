<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-xs-6 col-sm-4">
         <div class="itemBox">
			<div class="prod">
				<img src="<?php echo e(url('productimages')); ?>/<?php echo e($p->pro_img); ?>" alt=""  height="270px"/>
			</div>
			<label><?php echo e($p->pro_name); ?></label>
			<span class="hidden-xs">Code: <?php echo e($p->pro_code); ?></span>
    <br>
  <span class="hidden-xs"><?php echo e($p->pro_info); ?></span>
			<div class="addcart">
				<div class="price">Rs <?php echo e($p->pro_price); ?></div>
				<div class="cartIco hidden-xs"><a href="/"><img src="<?php echo e(asset('img/cart.png')); ?>"/> </a></div>
			</div>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>