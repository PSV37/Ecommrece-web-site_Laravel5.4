

<table style="width:100%" class="table table-hover table-striped" >
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr  style="height:50px">
    <td style="padding:10px"><?php echo e($pro->pro_name); ?></td>
    <td style="padding:10px"><?php echo e($pro->pro_code); ?></td>
    <td style="padding:10px"><?php echo e($pro->pro_price); ?></td>
    <td style="padding:10px"><?php echo e($pro->cat->cat_name); ?></td>
    <td><a class="btn btn-sm btn-fill btn-primary" href="<?php echo e(url('/admin/editProduct')); ?>/<?php echo e($pro->id); ?>">Edit</td>
    <td><a class="btn btn-sm btn-fill btn-danger" href="<?php echo e(url('/admin/deleteProduct')); ?>/<?php echo e($pro->id); ?>">Delete</td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

