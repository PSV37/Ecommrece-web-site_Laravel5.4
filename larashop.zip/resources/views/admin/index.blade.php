@extends('admin.master')
@section('title', 'Admin')

@section('content')
<div class="content">
  <h3>dashboad</h3>
</div>

@endsection