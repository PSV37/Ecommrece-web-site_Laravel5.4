@extends('admin.master')
@section('title', 'Admin')

@section('content')
<div class="content">
  <h3>profile</h3>
</div>

@endsection